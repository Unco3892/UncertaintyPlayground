# __init__.py
#from .m import stringLength
#from .stringToLower import stringToLower
#from .stringToUpper import stringToUpper